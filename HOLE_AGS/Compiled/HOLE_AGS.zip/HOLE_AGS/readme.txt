-H.O.L.E-  

The Hypogean Opening Lithotypical Expedition  

or: A game about a very deep hole  

Developed for the Monthly AGS contest of February 2026  
https://www.adventuregamestudio.co.uk/forums/competitions-activities/mags-february-hole-open/  

How to play: 
Use the down arrow key to slide down your rope and descend into the HOLE, let go to stop. If you stop at a high speed this will put strain on the rope and could cause it to snap, so be careful.
Use the right and left arrow keys to scan the walls around you. Let go of the button to scan where the reticle is currently at. Scanning objects gains you points for the final high score.
If you overshoot an object you can tap the up arrow key to climb up.
If you climb to the top of the screen you will exit the HOLE and end your run, which displays your score.


Sound Credits: 
Biting hard on a crunchy carrot by pfranzen -- https://freesound.org/s/381726/ -- License: Attribution 4.0  
Monster / Alien Eating by EchoCinematics -- https://freesound.org/s/533868/ -- License: Creative Commons 0  
cave echo.wav by TechRonin -- https://freesound.org/s/554141/ -- License: Creative Commons 0  
COMTran_Walkie Talkie Beep With Noise.Dispatch Signal.Artificial x3_EM by newlocknew -- https://freesound.org/s/808016/ -- License: Attribution 4.0  
click clack.wav by thomson93 -- https://freesound.org/s/183595/ -- License: Creative Commons 0  
tone beep amb verb.wav by Mossy4 -- https://freesound.org/s/263128/ -- License: Attribution 4.0  
beep4.wav by Freezeman -- https://freesound.org/s/153210/ -- License: Attribution 3.0  

Music Credits: 

"Crypto" Kevin MacLeod (incompetech.com)  
"Satiate - only strings" Kevin MacLeod (incompetech.com)  
"Ossuary 5 - Rest" Kevin MacLeod (incompetech.com)  
"Long Note Two" Kevin MacLeod (incompetech.com)  
"Shadowlands 6 - The Pit" Kevin MacLeod (incompetech.com)  
"SCP-x2x (Unseen Presence)" Kevin MacLeod (incompetech.com)  
"Giant Wyrm" Kevin MacLeod (incompetech.com)  
Licensed under Creative Commons: By Attribution 4.0 License  
http://creativecommons.org/licenses/by/4.0/  
